

package snakegame.ui;


public class Main {
    
    public static void main(String[] args) {
        
        GameUi.main(args);
        
    }
}